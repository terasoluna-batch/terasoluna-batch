/*
 * Copyright (c) 2007 NTT DATA Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jp.terasoluna.fw.util;

/**
 * {@link jp.terasoluna.fw.util.BeanUtilTest} �N���X�Ŏg�p����B
 * 
 * @see jp.terasoluna.fw.util.BeanUtilTest
 */
@SuppressWarnings("unused")
public class BeanUtil_BeanStub01 {
    
    private String param2 = null;

    /**
     * Exception���X���[����B
     * @return ������B
     * @throws Exception ��O
     */
    public String getParam1() throws Exception {
        throw new Exception();
    }
    
    /**
     * Exception���X���[����B
     * @param param1 �p�����[�^
     * @throws Exception ��O
     */
    public void setParam1(String param1) throws Exception {
        throw new Exception();
    }
    
    /**
     * param2��ԋp����B
     * 
     * @return param2
     */
    public String getParam2() {
        return param2;
    }
    
    /**
     * param2��ݒ肷��B
     * @param param2 �p�����[�^
     */
    public void setParam2(String param2) {
        this.param2 = param2;
    }
}
