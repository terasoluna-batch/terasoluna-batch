/**
 * JavaBean�֘A
 */
package jp.terasoluna.fw.beans;